import csv
import random
import numpy as np
import math

#need these files in same directory to run
filenames = ['sudoku_9x9.csv', 'sudoku_16x16_shuffled.csv', 'sudoku_25x25.csv', 'sudoku_36x36.csv', 'Sudoku_49x49_Board.csv', '64x64_Sudoku_Board.csv', 'sudoku_81x81.csv' ,'Shuffled_100x100_Sudoku_Board.csv']

def generate_puzzle_from_csv(filename, remove):

    with open(filename, 'r') as f:
        reader = csv.reader(f)
        board = [list(map(int, row)) for row in reader]

    board = np.array(board)
    size = board.shape[0]
    total = size * size

    # Randomly choose cells to remove
    indices = random.sample(range(total), remove)
    for idx in indices:
        r, c = divmod(idx, size)
        board[r, c] = 0

    # Print the puzzle
    for row in board:
        print(' '.join(f"{val:2}" for val in row))

    return board

index = int(input('Please enter the size of your desired board, 3 for 9x9, 4 for 16x16 ... 10 for 100x100: '))
#adjustable difficulty as prof suggested
difficulty = int(input('Please enter the desired difficulty, 0 easy, 1 medium, 2 hard: '))

size = index**4

index -= 3


if difficulty == 0:
    num_remove = int(size * 0.2)#removes 20% of squares
elif difficulty == 1:
    num_remove = int(size * 0.6)#removes 60% of squares
else:
    num_remove = int(size * 0.8)#removes 80% of squares

board = generate_puzzle_from_csv(filenames[index], num_remove)

